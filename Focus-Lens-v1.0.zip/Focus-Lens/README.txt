FOCUS LENS - Installation Instructions
======================================

METHOD 1: Simple Right-Click (Recommended)
-------------------------------------------
1. Right-click on "Focus Lens.app"
2. Select "Open" from the menu
3. Click "Open" in the security dialog
4. Grant Camera permission when prompted

METHOD 2: Terminal Install Script
----------------------------------
1. Open Terminal (Applications > Utilities > Terminal)
2. Type: cd 
3. Drag this folder into Terminal (adds the path)
4. Press Enter
5. Type: bash install.sh
6. Press Enter

The app is safe - the warning is just because it's not signed with
an Apple Developer certificate ($99/year, not needed for testing).

Need help? Check the full documentation in DISTRIBUTION_GUIDE.md

Enjoy! 🎯
